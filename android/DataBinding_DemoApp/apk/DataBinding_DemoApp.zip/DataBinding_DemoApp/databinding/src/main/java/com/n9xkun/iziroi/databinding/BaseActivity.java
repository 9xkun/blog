package com.n9xkun.iziroi.databinding;

import android.app.Activity;

/**
 * Các event chung cho toàn bộ activity sẽ ở đây
 */
public class BaseActivity extends Activity {
  //menu go here

}
